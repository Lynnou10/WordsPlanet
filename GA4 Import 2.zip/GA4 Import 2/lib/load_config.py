import json
import glob

def loadConfig(configFolderPath):
    configFilesList = glob.glob("{path}/*".format(path=configFolderPath))
    dataSourcesToRefresh =  []
    for file in configFilesList:
        f = open(file)
        data = json.load(f)
        dataSourcesToRefresh.append(data)
        f.close()
    return dataSourcesToRefresh




