from datetime import datetime, timedelta

def loadImportDateRanges(startDate):
    startDate = datetime.strptime(startDate, "%Y-%m-%d")
    endDate = datetime.now() - timedelta(1)
    endDate = endDate.replace(hour=0, minute=0, second=0, microsecond=0)
    dateRanges = []
    
    while(startDate <= endDate):
        calculatedEnddate = startDate + timedelta(6)
        calculatedEnddate = calculatedEnddate if calculatedEnddate < endDate else endDate
        dateRanges.append({
            "startDate": startDate.strftime("%Y-%m-%d"),
            "endDate": calculatedEnddate.strftime("%Y-%m-%d")
        })
        startDate = startDate + timedelta(7)
    return dateRanges


def formatDate(date):
    return datetime.strptime(date, "%Y%m%d")
