from config.index import property_id, secret_key_path
from google.oauth2 import service_account
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import (
    DateRange,
    Dimension,
    Metric,
    RunReportRequest,
    FilterExpression,
    Filter
)
import pandas as pd


tracked_events = df=pd.array([
    'login_event_visit',
    'orders_page_visit',
    'sale_page_visit',
    'click_menu_visit',
    'filter_set_visit',
    'watchlist_page_visit',
    'login_page_visit',
    'live_page_visit',
    'sale_type_page_visit',
    'lots_page_visit',
    'query_searched_visit',
    'country_page_visit',
    'account_page_visithome_page_visit',
    'new_user_signup_started_visit',
    'footer_clicked_visit',
    'make_page_visit',
    'notfound_page_visit',
    'contact_initiated_visit',
    'click_refresh_page_visit',
    'dashboard_page_visit',
    'forgot_login_page_visit',
    'save_search_bell_click_visit',
    'content_page_visit',
    'existing_user_signup_started_visit',
    'new_user_signup_completed_visit',
    'request_new_password_visit',
    'new_user_signup_contact_visit',
    'internal_campaign_visit',
    'watchlist_add_visit',
    'bid_placed'
])


def getFeatureByCountry(dateRanges, dataSourceName):
    credentials = service_account.Credentials.from_service_account_file(secret_key_path)
    client = BetaAnalyticsDataClient(credentials=credentials)

    data = None

    for dateRange in dateRanges:
        print("{source} importing from {startDate} to {endDate}".format(source=dataSourceName, startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
        featureByCountrySessions = getFeatureByCountrySessions(client, dateRange)
        featureByCountrySessionWithBids = getFeatureByCountryGlobalSessionWithBids(client, dateRange)
        featureByCountryLoggedSession = getFeatureByCountryLoggedSessionsData(client, dateRange)
        


        result = pd.merge(featureByCountrySessions, featureByCountrySessionWithBids, on=["Date", "Country"], how="outer")
        result = pd.merge(result, featureByCountryLoggedSession, on=["Date", "Country"], how="outer")
        result.fillna(0, inplace=True)

        result["GlobalSessionsWithBids"] = result["GlobalSessions"] * result["GlobalBidConversionRate"]
        result["GlobalSessionsWithBids"] = result["GlobalSessionsWithBids"].round()
        result["GlobalSessionsWithBids"] = result["GlobalSessionsWithBids"].astype(int)
        result = result.drop(columns=['GlobalBidConversionRate'])

        result = result.sort_values(by=['Date', 'Country'], ascending=True)
        result.fillna(0, inplace=True)

        if data is not None:
            data = pd.concat([data, result], axis=0)
        else:
            data = result

    data = data[data["EventName"].isin(tracked_events)]  
    data.fillna(0, inplace=True)

    print("{source} imported".format(source=dataSourceName))
    return data

def getFeatureByCountrySessions(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="customEvent:site_country_event"),
            Dimension(name="eventName")
        ],
        metrics=[
            Metric(name="sessions")
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])]
        
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("FeatureByCountrySessions data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    sessions = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Country": [row.dimension_values[1].value for row in response.rows],
        "EventName": [row.dimension_values[2].value for row in response.rows],
        "Sessions": [row.metric_values[0].value for row in response.rows]
    })
    sessions["Sessions"] = sessions["Sessions"].astype(int)

    sessions.fillna(0, inplace=True)

    return sessions

def getFeatureByCountryGlobalSessionWithBids(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="customEvent:site_country_event")
        ],
        metrics=[
            Metric(name="sessions"),
            Metric(name="conversions:bid_count"),
            Metric(name="sessionConversionRate:bid_count")
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])]
        
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("FeatureByCountrySessionWithBids data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    sessionsWithBids = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Country": [row.dimension_values[1].value for row in response.rows],
        "GlobalSessions": [row.metric_values[0].value for row in response.rows],
        "GlobalBids": [row.metric_values[1].value for row in response.rows],
        "GlobalBidConversionRate": [row.metric_values[2].value for row in response.rows]
    })

    sessionsWithBids = sessionsWithBids.loc[(sessionsWithBids["Country"] != "") & (sessionsWithBids["Country"] != "(not set)")]
    sessionsWithBids["GlobalSessions"] = sessionsWithBids["GlobalSessions"].astype(int)
    sessionsWithBids["GlobalBids"] = sessionsWithBids["GlobalBids"].astype(int)
    sessionsWithBids["GlobalBidConversionRate"] = sessionsWithBids["GlobalBidConversionRate"].astype(float)

    sessionsWithBids.fillna(0, inplace=True)

    return sessionsWithBids


def getFeatureByCountryLoggedSessionsData(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="customEvent:site_country_event")
        ],
        metrics=[Metric(name="sessions")],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])],
        dimension_filter=FilterExpression(
            filter=Filter(
                field_name="customUser:contains_user_info",
                string_filter=Filter.StringFilter(value="True"),
            )
        )
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("FeatureByCountryLoggedSessionsData data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    loggedSessions = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Country": [row.dimension_values[1].value for row in response.rows],
        "GlobalLoggedSessions": [row.metric_values[0].value for row in response.rows]
    })

    loggedSessions["GlobalLoggedSessions"] = loggedSessions["GlobalLoggedSessions"].astype(int)
    loggedSessions.fillna(0, inplace=True)

    return loggedSessions