from config.index import property_id, secret_key_path
from google.oauth2 import service_account
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import (
    DateRange,
    Dimension,
    Metric,
    RunReportRequest,
    FilterExpression,
    Filter
)
import pandas as pd

def getFilters(dateRanges, dataSourceName):
    credentials = service_account.Credentials.from_service_account_file(secret_key_path)
    client = BetaAnalyticsDataClient(credentials=credentials)

    data = None

    for dateRange in dateRanges:
        print("{source} importing from {startDate} to {endDate}".format(source=dataSourceName, startDate=dateRange["startDate"], endDate=dateRange["endDate"]))

        sessionsWithBids = getFiltersSessionWithBids(client, dateRange)
        filtersHits = getFilterHits(client, dateRange)

        result = pd.merge(sessionsWithBids, filtersHits, on=["Date", "Filter"], how="outer")
        result["SessionsWithBids"] = result["Sessions"] * result["BidConversionRate"]
        result["SessionsWithBids"] = result["SessionsWithBids"].round()
        result = result.drop(columns=['BidConversionRate'])
        result = result[["Date", "Filter", "Sessions", "SessionsWithBids", "Bids", "Hits"]]

        result = result.sort_values(by='Date', ascending=True)
        result.fillna(0, inplace=True)
        result["Sessions"] = result["Sessions"].astype(int)
        result["Bids"] = result["Bids"].astype(int)
        result["Hits"] = result["Hits"].astype(int)

        if data is not None:
            data = pd.concat([data, result], axis=0)
        else:
            data = result

    print("{source} imported".format(source=dataSourceName))
    return data

def getFiltersSessionWithBids(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="customEvent:filter_info_event")
        ],
        metrics=[
            Metric(name="sessions"),
            Metric(name="sessionConversionRate:bid_count"),
            Metric(name="conversions:bid_count")
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])]
        
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("FiltersSessionWithBids data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    sessionsWithBids = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Filter": [row.dimension_values[1].value for row in response.rows],
        "Sessions": [row.metric_values[0].value for row in response.rows],
        "BidConversionRate": [row.metric_values[1].value for row in response.rows],
        "Bids": [row.metric_values[2].value for row in response.rows],
    })

    sessionsWithBids = sessionsWithBids.loc[(sessionsWithBids["Filter"] != "") & (sessionsWithBids["Filter"] != "(not set)")]
    sessionsWithBids["BidConversionRate"] = sessionsWithBids["BidConversionRate"].astype(float)
    sessionsWithBids["Sessions"] = sessionsWithBids["Sessions"].astype(int)
    sessionsWithBids["Bids"] = sessionsWithBids["Bids"].astype(int)

    sessionsWithBids.fillna(0, inplace=True)

    return sessionsWithBids

def getFilterHits(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="customEvent:filter_info_event"),
            Dimension(name="eventName")
        ],
        metrics=[Metric(name="eventCount")],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])],
        dimension_filter=FilterExpression(
            filter=Filter(
                field_name="eventName",
                string_filter=Filter.StringFilter(value="filter_set"),
            )
        )
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("FilterHits data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    filtersHits = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Filter": [row.dimension_values[1].value for row in response.rows],
        "Hits": [row.metric_values[0].value for row in response.rows]
    })

    filtersHits = filtersHits.loc[(filtersHits["Filter"] != "") & (filtersHits["Filter"] != "(not set)")]

    filtersHits["Hits"] = filtersHits["Hits"].astype(int)

    filtersHits.fillna(0, inplace=True)

    return filtersHits

