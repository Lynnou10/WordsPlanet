from config.index import property_id, secret_key_path
from google.oauth2 import service_account
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import (
    DateRange,
    Dimension,
    Metric,
    RunReportRequest
)
import pandas as pd

tracked_events = df=pd.array([
    'account_page_view',
    'account_page_visit',
    'account_trader_info_click',
    'account_trader_info_click_visit',
    'account_documents_click',
    'account_documents_click_visit',
    'account_shareholding_info_click',
    'account_shareholding_info_click_visit',
    'account_emails_click',
    'account_emails_click_visit',
    'account_details_click',
    'account_details_click_visit',
    'account_company_info_click',
    'account_company_info_click_visit'
])


def getAccountMetrics(dateRanges, dataSourceName):
    credentials = service_account.Credentials.from_service_account_file(secret_key_path)
    client = BetaAnalyticsDataClient(credentials=credentials)

    data = None

    for dateRange in dateRanges:
        print("{source} importing from {startDate} to {endDate}".format(source=dataSourceName, startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
        result = getAccountMetricsEvents(client, dateRange)
        result = result.sort_values(by=['Date'], ascending=True)


        


        result.fillna(0, inplace=True)

        if data is not None:
            data = pd.concat([data, result], axis=0)
        else:
            data = result

    data = data[data["EventName"].isin(tracked_events)]
    data = data.pivot(index='Date', columns='EventName')
    data = data.reset_index() 
    data.columns = data.columns.droplevel(0)
    data.rename(columns={ data.columns[0]: "Date" }, inplace = True)
    data.fillna(0, inplace=True)

    print(data)

    print("{source} imported".format(source=dataSourceName))
    return data

def getAccountMetricsEvents(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="eventName")
        ],
        metrics=[
            Metric(name="eventCount")
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])]
        
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("AccountMetricsEvents data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    events = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "EventName": [row.dimension_values[1].value for row in response.rows],
        "EventCount": [row.metric_values[0].value for row in response.rows]
    })
    events["EventCount"] = events["EventCount"].astype(int)

    events.fillna(0, inplace=True)

    return events