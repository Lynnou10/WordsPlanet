from config.index import property_id, secret_key_path
from google.oauth2 import service_account
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import (
    DateRange,
    Dimension,
    Metric,
    RunReportRequest
)
import pandas as pd

def getFilterFuelTypes(dateRanges, dataSourceName):
    credentials = service_account.Credentials.from_service_account_file(secret_key_path)
    client = BetaAnalyticsDataClient(credentials=credentials)

    data = None

    for dateRange in dateRanges:
        print("{source} importing from {startDate} to {endDate}".format(source=dataSourceName, startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
        result = getFilterFuelTypesSessions(client, dateRange)

        result["SessionsWithBids"] = result["Sessions"] * result["BidConversionRate"]
        result["SessionsWithBids"] = result["SessionsWithBids"].round()
        result["SessionsWithBids"] = result["SessionsWithBids"].astype(int)

        result = result.drop(columns=['BidConversionRate'])

        result = result.sort_values(by='Date', ascending=True)
        result.fillna(0, inplace=True)
        result["Sessions"] = result["Sessions"].astype(int)
        result["SessionsWithBids"] = result["SessionsWithBids"].astype(int)

        if data is not None:
            data = pd.concat([data, result], axis=0)
        else:
            data = result

    print("{source} imported".format(source=dataSourceName))
    return data

def getFilterFuelTypesSessions(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="customEvent:filter_fuel_types_event")
        ],
        metrics=[
            Metric(name="sessions"),
            Metric(name="sessionConversionRate:bid_count")
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])]
        
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("FilterFuelTypesSessions data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    sessions = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "FilterFuelType": [row.dimension_values[1].value for row in response.rows],
        "Sessions": [row.metric_values[0].value for row in response.rows],
        "BidConversionRate": [row.metric_values[1].value for row in response.rows]
    })

    sessions = sessions.loc[(sessions["FilterFuelType"] != "") & (sessions["FilterFuelType"] != "(not set)")]
    sessions["Sessions"] = sessions["Sessions"].astype(int)
    sessions["BidConversionRate"] = sessions["BidConversionRate"].astype(float)

    sessions.fillna(0, inplace=True)

    return sessions
