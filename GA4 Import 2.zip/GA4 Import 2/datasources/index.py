from datasources.sources.feature_by_country import getFeatureByCountry
from datasources.sources.feature import getFeature

from datasources.sources.campaigns_clicks import getCampaignsClicks
from datasources.sources.campaigns_details import getCampaignsDetails
from datasources.sources.campaigns_mediums_metrics import getCampaignsMediumsMetrics
from datasources.sources.campaigns_metrics import getCampaignsMetrics
from datasources.sources.campaigns import getCampaigns
from datasources.sources.countries import getCountries
from datasources.sources.country_search import getCountrySearch
from datasources.sources.country_fueltypes import getCountryFuelTypes
from datasources.sources.country_makes import getCountryMakes
from datasources.sources.country_models import getCountryModels
from datasources.sources.country_saletypes import getCountrySaleTypes
from datasources.sources.filter_countries import getFilterCountries
from datasources.sources.filter_models import getFilterModels
from datasources.sources.filter_makes import getFilterMakes
from datasources.sources.filter_saletypes import getFilterSaleTypes
from datasources.sources.filter_fueltypes import getFilterFuelTypes
from datasources.sources.filters import getFilters
from datasources.sources.account_metrics import getAccountMetrics

datasources = {
    "GA4 - Feature by country": getFeatureByCountry,
    "GA4 - Feature": getFeature,
    "GA4 - Campaigns Clicks": getCampaignsClicks,
    "GA4 - Campaigns Details": getCampaignsDetails,
    "GA4 - Campaigns Mediums Metrics": getCampaignsMediumsMetrics,
    "GA4 - Campaigns Metrics": getCampaignsMetrics,
    "GA4 - Campaigns": getCampaigns,
    "GA4 - Countries": getCountries,
    "GA4 - Country Search": getCountrySearch,
    "GA4 - Country FuelTypes": getCountryFuelTypes,
    "GA4 - Country Makes": getCountryMakes,
    "GA4 - Country Models": getCountryModels,
    "GA4 - Country SaleTypes": getCountrySaleTypes,
    "GA4 - Filter Countries": getFilterCountries,
    "GA4 - Filter Sale Types": getFilterSaleTypes,
    "GA4 - Filter Models": getFilterModels,
    "GA4 - Filter Makes": getFilterMakes,
    "GA4 - Filter Fuel Types": getFilterFuelTypes,
    "GA4 - Filters": getFilters,
    "GA4 - Account Metrics": getAccountMetrics
}