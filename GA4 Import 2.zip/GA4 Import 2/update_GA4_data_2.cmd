python ./update_GA4_data_2.py
pause