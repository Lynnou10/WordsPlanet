import os
import sys
from lib.load_config import loadConfig
from lib.datasource_file import getLastRefreshDateFromDatasourceFile, insertResult, insertResultFaster, saveResultFaster, loadDatasource
from lib.date import loadImportDateRanges
from datasources.index import datasources
import warnings

warnings.simplefilter("ignore")

os.environ['HTTPS_PROXY'] = 'http://hq-proxynossl:80'
arguments = sys.argv
arguments.pop(0)

dataSourcesToRefresh = loadConfig(".\\config\\sources")
print("----------")
print('Loading histo')
histoData = loadDatasource()
print('Histo loaded')
print("----------")

for dataSource in dataSourcesToRefresh:
    if(len(arguments) == 0 or dataSource["fileSheetName"] in arguments):
        print("----------")
        print("{source} import start".format(source=dataSource["name"]))
        startDate = getLastRefreshDateFromDatasourceFile(histoData, dataSource)
        dateRanges = loadImportDateRanges(startDate)
        if(len(dateRanges) > 0):
            result = datasources[dataSource['name']](dateRanges, dataSource["name"])
            # insertResult(histoData, dataSource, result, startDate)
            insertResultFaster(histoData, dataSource, result, startDate)
            print("{source} import OK".format(source=dataSource["name"]))
            print("----------")
        else:
            print("ERROR during {source} update".format(source=dataSource["name"]))
            print("----------")
print("----------")
print('Saving new file')
saveResultFaster()
print('New file saved')
print("----------")