import os.path
import os
import pandas as pd
from lib.date import formatDate
from datetime import timedelta
import openpyxl
from pyexcelerate import Workbook
import numpy as np

DATASOURCE_FILE_LOCATION_PATH = '{path}/../data/ga4_data.xlsx'.format(path=os.path.dirname(os.path.abspath(__file__)))
DATASOURCE_FAST_FILE_LOCATION_PATH = '{path}/../data/output.xlsx'.format(path=os.path.dirname(os.path.abspath(__file__)))
DATASOURCE_FAST_FILE_OLD_LOCATION_PATH = '{path}/../data/ga4_data_old.xlsx'.format(path=os.path.dirname(os.path.abspath(__file__)))


def loadDatasource():
    if datasourceFileExists():
        return pd.read_excel(DATASOURCE_FILE_LOCATION_PATH, sheet_name=None)
    return 

def datasourceFileExists():
    fileExists = os.path.isfile(DATASOURCE_FILE_LOCATION_PATH)
    return fileExists

def datasourceSheetExists(histoData, dataSourceSheetName):
    if datasourceFileExists():
        return dataSourceSheetName in histoData
    else: 
        return False

def getLastRefreshDateFromDatasourceFile(histoData, dataSource):
    sheetExists = datasourceSheetExists(histoData, dataSource["fileSheetName"])

    if not sheetExists:
        return dataSource['startDate']
    else:
        histo = histoData[dataSource["fileSheetName"]]
        date = formatDate(histo["Date"].max().astype('str'))
        # date = date + timedelta(1)
        date = date - timedelta(2)
        return date.strftime("%Y-%m-%d")

def insertResult(histoData, dataSource, data, startDate):
    if not datasourceFileExists():
        data.to_excel(DATASOURCE_FILE_LOCATION_PATH, sheet_name=dataSource["fileSheetName"], index=False)  
    elif not datasourceSheetExists(histoData, dataSource["fileSheetName"]):
        with pd.ExcelWriter(DATASOURCE_FILE_LOCATION_PATH, engine='openpyxl', mode='a') as writer:
            data.to_excel(writer, sheet_name=dataSource["fileSheetName"], index=False)
    else:
        histo = histoData[dataSource["fileSheetName"]]
        histo = histo.loc[histo['Date'] < int(startDate.replace('-', ''))]
        data = pd.concat([histo, data], axis=0)
        deleteSheetFromExcelFile(dataSource["fileSheetName"])
        with pd.ExcelWriter(DATASOURCE_FILE_LOCATION_PATH, engine='openpyxl', mode='a') as writer:
            data.to_excel(writer, sheet_name=dataSource["fileSheetName"], index=False)
    print("{source} refreshed in Excel file".format(source=dataSource["name"]))


fastWorkBook = Workbook()
DATASOURCE_FAST_FILE_LOCATION_PATH

def insertResultFaster(histoData, dataSource, data, startDate):
    if not datasourceFileExists():
        fastWorkBook.new_sheet(dataSource["fileSheetName"], data=np.concatenate([[data.keys()], data.to_numpy()]))
    elif not datasourceSheetExists(histoData, dataSource["fileSheetName"]):
        fastWorkBook.new_sheet(dataSource["fileSheetName"], data=np.concatenate([[data.keys()], data.to_numpy()]))
    else:
        histo = histoData[dataSource["fileSheetName"]]
        histo = histo.loc[histo['Date'] < int(startDate.replace('-', ''))]
        data = pd.concat([histo, data], axis=0)
        data = data.replace(r'^\s*$', '(not set)', regex=True)
        data.fillna(value='(not set)', inplace=True)
        fastWorkBook.new_sheet(dataSource["fileSheetName"], data=np.concatenate([[data.keys()], data.to_numpy()]))
    print("{source} refreshed in Excel file".format(source=dataSource["name"]))

def saveResultFaster():
    fastWorkBook.save(DATASOURCE_FAST_FILE_LOCATION_PATH)
    
def deleteSheetFromExcelFile(dataSourceSheetName):
    excelFile = openpyxl.load_workbook(DATASOURCE_FILE_LOCATION_PATH)
    del excelFile[dataSourceSheetName]
    excelFile.save(DATASOURCE_FILE_LOCATION_PATH)


        
    
        




                   