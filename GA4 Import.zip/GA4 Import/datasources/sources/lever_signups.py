from config.index import property_id, secret_key_path 
from google.oauth2 import service_account
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import (
    DateRange,
    Dimension,
    Metric,
    RunReportRequest,
    FilterExpression,
    Filter
)
import pandas as pd

def getLeverSignUps(dateRanges, dataSourceName):
    credentials = service_account.Credentials.from_service_account_file(secret_key_path)
    client = BetaAnalyticsDataClient(credentials=credentials)

    data = None

    for dateRange in dateRanges:
        print("{source} importing from {startDate} to {endDate}".format(source=dataSourceName, startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
        session = getLeversSession(client, dateRange)
        leverNewUserSignupStartedVisit = getLeverNewUserSignupStartedVisit(client, dateRange)
        leverNewUserSignupContactVisit = getLeverNewUserSignupContactVisit(client, dateRange)
        leverNewUserSignupCompletedVisit = getLeverNewUserSignupCompletedVisit(client, dateRange)
        leverNewUserSignupRejectedVisit = getLeverNewUserSignupRejectedVisit(client, dateRange)
        leverExistingUserSignupStartedVisit = getLeverExistingUserSignupStartedVisit(client, dateRange)
        leverExistingUserSignupVisit = getLeverExistingUserSignupVisit(client, dateRange)

        result = pd.merge(session, leverNewUserSignupStartedVisit, on=["Date", "Lever"], how="outer")
        result = pd.merge(result, leverNewUserSignupContactVisit, on=["Date", "Lever"], how="outer")
        result = pd.merge(result, leverNewUserSignupCompletedVisit, on=["Date", "Lever"], how="outer")
        result = pd.merge(result, leverNewUserSignupRejectedVisit, on=["Date", "Lever"], how="outer")
        result = pd.merge(result, leverExistingUserSignupStartedVisit, on=["Date", "Lever"], how="outer")
        result = pd.merge(result, leverExistingUserSignupVisit, on=["Date", "Lever"], how="outer")

        result = result.sort_values(by='Date', ascending=True)
        result.fillna(0, inplace=True)
        result["Sessions"] = result["Sessions"].astype(int)
        result["NewUserSignupStartedVisit"] = result["NewUserSignupStartedVisit"].astype(int)
        result["NewUserSignupContactVisit"] = result["NewUserSignupContactVisit"].astype(int)
        result["NewUserSignupCompletedVisit"] = result["NewUserSignupCompletedVisit"].astype(int)
        result["NewUserSignupRejectedVisit"] = result["NewUserSignupRejectedVisit"].astype(int)
        result["ExistingUserSignupStartedVisit"] = result["ExistingUserSignupStartedVisit"].astype(int)
        result["ExistingUserSignupVisit"] = result["ExistingUserSignupVisit"].astype(int)

        if data is not None:
            data = pd.concat([data, result], axis=0)
        else:
            data = result

    print("{source} imported".format(source=dataSourceName))
    return data

def getLeversSession(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="sessionPrimaryChannelGroup")
        ],
        metrics=[
            Metric(name="sessions")
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])]
        
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("LeversSession data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    data = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Lever": [row.dimension_values[1].value for row in response.rows],
        "Sessions": [row.metric_values[0].value for row in response.rows]
    })

    data["Sessions"] = data["Sessions"].astype(int)
    data.fillna(0, inplace=True)

    return data

def getLeverNewUserSignupStartedVisit(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="sessionPrimaryChannelGroup"),
            Dimension(name="eventName")
        ],
        metrics=[
            Metric(name="eventCount")
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])],
        dimension_filter=FilterExpression(
            filter=Filter(
                field_name="eventName",
                string_filter=Filter.StringFilter(value="new_user_signup_started_visit"),
            )
        )
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("NewUserSignupStartedVisit data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    data = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Lever": [row.dimension_values[1].value for row in response.rows],
        "NewUserSignupStartedVisit": [row.metric_values[0].value for row in response.rows]
    })

    data.fillna(0, inplace=True)

    return data

def getLeverNewUserSignupContactVisit(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="sessionPrimaryChannelGroup"),
            Dimension(name="eventName")
        ],
        metrics=[
            Metric(name="eventCount")
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])],
        dimension_filter=FilterExpression(
            filter=Filter(
                field_name="eventName",
                string_filter=Filter.StringFilter(value="new_user_signup_contact_visit"),
            )
        )
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("LeverNewUserSignupContactVisit data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    data = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Lever": [row.dimension_values[1].value for row in response.rows],
        "NewUserSignupContactVisit": [row.metric_values[0].value for row in response.rows]
    })

    data.fillna(0, inplace=True)

    return data

def getLeverNewUserSignupCompletedVisit(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="sessionPrimaryChannelGroup"),
            Dimension(name="eventName")
        ],
        metrics=[
            Metric(name="eventCount")
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])],
        dimension_filter=FilterExpression(
            filter=Filter(
                field_name="eventName",
                string_filter=Filter.StringFilter(value="new_user_signup_completed_visit"),
            )
        )
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("NewUserSignupCompletedVisit data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    data = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Lever": [row.dimension_values[1].value for row in response.rows],
        "NewUserSignupCompletedVisit": [row.metric_values[0].value for row in response.rows]
    })

    data.fillna(0, inplace=True)

    return data

def getLeverNewUserSignupRejectedVisit(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="sessionPrimaryChannelGroup"),
            Dimension(name="eventName")
        ],
        metrics=[
            Metric(name="eventCount")
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])],
        dimension_filter=FilterExpression(
            filter=Filter(
                field_name="eventName",
                string_filter=Filter.StringFilter(value="new_user_signup_rejected_visit"),
            )
        )
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("NewUserSignupRejectedVisit data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    data = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Lever": [row.dimension_values[1].value for row in response.rows],
        "NewUserSignupRejectedVisit": [row.metric_values[0].value for row in response.rows]
    })

    data.fillna(0, inplace=True)

    return data

def getLeverExistingUserSignupStartedVisit(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="sessionPrimaryChannelGroup"),
            Dimension(name="eventName")
        ],
        metrics=[
            Metric(name="eventCount")
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])],
        dimension_filter=FilterExpression(
            filter=Filter(
                field_name="eventName",
                string_filter=Filter.StringFilter(value="existing_user_signup_started_visit"),
            )
        )
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("ExistingUserSignupStartedVisit data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    data = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Lever": [row.dimension_values[1].value for row in response.rows],
        "ExistingUserSignupStartedVisit": [row.metric_values[0].value for row in response.rows]
    })

    data.fillna(0, inplace=True)

    return data

def getLeverExistingUserSignupVisit(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="sessionPrimaryChannelGroup"),
            Dimension(name="eventName")
        ],
        metrics=[
            Metric(name="eventCount")
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])],
        dimension_filter=FilterExpression(
            filter=Filter(
                field_name="eventName",
                string_filter=Filter.StringFilter(value="existing_user_signup_visit"),
            )
        )
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("ExistingUserSignupVisit data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    data = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Lever": [row.dimension_values[1].value for row in response.rows],
        "ExistingUserSignupVisit": [row.metric_values[0].value for row in response.rows]
    })

    data.fillna(0, inplace=True)

    return data
