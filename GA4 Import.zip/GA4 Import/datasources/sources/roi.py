from config.index import property_id, secret_key_path 
from google.oauth2 import service_account
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import (
    DateRange,
    Dimension,
    Metric,
    RunReportRequest,
    FilterExpression,
    Filter
)
import pandas as pd

def getROI(dateRanges, dataSourceName):
    credentials = service_account.Credentials.from_service_account_file(secret_key_path)
    client = BetaAnalyticsDataClient(credentials=credentials)

    data = None

    for dateRange in dateRanges:
        print("{source} importing from {startDate} to {endDate}".format(source=dataSourceName, startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
        roiData = getROISessionBidsSignUps(client, dateRange)
        roiCost = getROICosts(client, dateRange)
        # leversLoggedSessions = getROILoggedSessions(client, dateRange)

        # result = pd.merge(leversData, leversLoggedSessions, on=["Date", "Campaign", "Lever"], how="outer")



        result = pd.merge(roiData, roiCost, on=["Date", "Campaign"], how="outer")


        result["SessionsWithBids"] = result["Sessions"] * result["BidConversionRate"]
        result["SessionsWithBids"] = result["SessionsWithBids"].round()
        # result["SessionsWithBids"] = result["SessionsWithBids"].astype(int)

        result["SessionsWithSignUps"] = result["Sessions"] * result["SignUpConversionRate"]
        result["SessionsWithSignUps"] = result["SessionsWithSignUps"].round()
        # result["SessionsWithSignUps"] = result["SessionsWithSignUps"].astype(int)

        result["SessionsWithExistingSignUps"] = result["Sessions"] * result["ExistingUserSignUpsConversionRate"]
        result["SessionsWithExistingSignUps"] = result["SessionsWithExistingSignUps"].round()
        # result["SessionsWithExistingSignUps"] = result["SessionsWithExistingSignUps"].astype(int)

        result = result.drop(columns=['BidConversionRate', 'SignUpConversionRate', 'ExistingUserSignUpsConversionRate'])

        

        result = result.sort_values(by='Date', ascending=True)
        result.fillna(0, inplace=True)
        result["Sessions"] = result["Sessions"].astype(int)
        result["BounceRate"] = result["BounceRate"].astype(float)
        result["TotalUsers"] = result["TotalUsers"].astype(int)
        result["SessionsWithBids"] = result["SessionsWithBids"].astype(int)
        result["SessionsWithSignUps"] = result["SessionsWithSignUps"].astype(int)
        result["SessionsWithExistingSignUps"] = result["SessionsWithExistingSignUps"].astype(int)
        result["Cost"] = result["Cost"].astype(float)
        # result["LoggedSessions"] = result["LoggedSessions"].astype(int)

        if data is not None:
            data = pd.concat([data, result], axis=0)
        else:
            data = result

    print("{source} imported".format(source=dataSourceName))
    return data

def getROISessionBidsSignUps(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="CampaignName"),
            Dimension(name="PrimaryChannelGroup")
        ],
        metrics=[
            Metric(name="sessions"),
            Metric(name="bounceRate"),
            Metric(name="totalUsers"),
            Metric(name="sessionConversionRate:new_user_signup_completed"),
            Metric(name="sessionConversionRate:bid_count"),
            Metric(name="sessionConversionRate:existing_user_signup")
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])]
        
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("ROISessionBidsSignUps data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    sessionsWithBidsSignUps = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Campaign": [row.dimension_values[1].value for row in response.rows],
        "Lever": [row.dimension_values[2].value for row in response.rows],
        "Sessions": [row.metric_values[0].value for row in response.rows],
        "BounceRate": [row.metric_values[1].value for row in response.rows],
        "TotalUsers": [row.metric_values[2].value for row in response.rows],
        "SignUpConversionRate": [row.metric_values[3].value for row in response.rows],
        "BidConversionRate": [row.metric_values[4].value for row in response.rows],
        "ExistingUserSignUpsConversionRate": [row.metric_values[5].value for row in response.rows]
    })

    sessionsWithBidsSignUps["Sessions"] = sessionsWithBidsSignUps["Sessions"].astype(int)
    sessionsWithBidsSignUps["BounceRate"] = sessionsWithBidsSignUps["BounceRate"].astype(float)
    sessionsWithBidsSignUps["TotalUsers"] = sessionsWithBidsSignUps["TotalUsers"].astype(int)
    sessionsWithBidsSignUps["SignUpConversionRate"] = sessionsWithBidsSignUps["SignUpConversionRate"].astype(float)
    sessionsWithBidsSignUps["BidConversionRate"] = sessionsWithBidsSignUps["BidConversionRate"].astype(float)
    sessionsWithBidsSignUps["ExistingUserSignUpsConversionRate"] = sessionsWithBidsSignUps["ExistingUserSignUpsConversionRate"].astype(float)
    sessionsWithBidsSignUps.fillna(0, inplace=True)

    return sessionsWithBidsSignUps


def getROICosts(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="CampaignName")
        ],
        metrics=[Metric(name="advertiserAdCost")],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])]
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("ROICosts data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    roiCosts = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Campaign": [row.dimension_values[1].value for row in response.rows],
        "Cost": [row.metric_values[0].value for row in response.rows]
    })

    roiCosts["Cost"] = roiCosts["Cost"].astype(float)
    roiCosts.fillna(0, inplace=True)

    return roiCosts

def getROILoggedSessions(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="sessionCampaignName"),
            Dimension(name="sessionPrimaryChannelGroup")
        ],
        metrics=[Metric(name="sessions")],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])],
        dimension_filter=FilterExpression(
            filter=Filter(
                field_name="customUser:contains_user_info",
                string_filter=Filter.StringFilter(value="True"),
            )
        )
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("ROILoggedSessions data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    loggedSessions = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Campaign": [row.dimension_values[1].value for row in response.rows],
        "Lever": [row.dimension_values[2].value for row in response.rows],
        "LoggedSessions": [row.metric_values[0].value for row in response.rows]
    })

    loggedSessions["LoggedSessions"] = loggedSessions["LoggedSessions"].astype(int)
    loggedSessions.fillna(0, inplace=True)

    return loggedSessions
