from config.index import property_id, secret_key_path 
from google.oauth2 import service_account
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import (
    DateRange,
    Dimension,
    Metric,
    RunReportRequest,
    FilterExpression,
    Filter
)
import pandas as pd

def getLostConnections(dateRanges, dataSourceName):
    credentials = service_account.Credentials.from_service_account_file(secret_key_path)
    client = BetaAnalyticsDataClient(credentials=credentials)

    data = None

    for dateRange in dateRanges:
        print("{source} importing from {startDate} to {endDate}".format(source=dataSourceName, startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
        browserSessions = getBrowsersSessions(client, dateRange)
        lostConnectionSessions = getLostConnectionsSessions(client, dateRange)

        result = pd.merge(browserSessions, lostConnectionSessions, on=["Date", "Browser"], how="outer")

        result["SessionsWithBids"] = result["Sessions"] * result["BidConversionRate"]
        result["SessionsWithBids"] = result["SessionsWithBids"].round()
        # result["SessionsWithBids"] = result["SessionsWithBids"].astype(int)

        result = result.drop(columns=['BidConversionRate'])
        result = result[["Date", "Browser", "Sessions", "SessionsWithBids", "LostConnectionsSessions"]]

        result = result.sort_values(by='Date', ascending=True)
        result.fillna(0, inplace=True)
        result["Sessions"] = result["Sessions"].astype(int)
        result["SessionsWithBids"] = result["SessionsWithBids"].astype(int)
        result["LostConnectionsSessions"] = result["LostConnectionsSessions"].astype(int)

        if data is not None:
            data = pd.concat([data, result], axis=0)
        else:
            data = result

    print("{source} imported".format(source=dataSourceName))
    return data

def getBrowsersSessions(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="browser")
        ],
        metrics=[
            Metric(name="sessions"),
            Metric(name="sessionConversionRate:bid_count"),
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])]
        
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("BrowsersSessions data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    sessions = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Browser": [row.dimension_values[1].value for row in response.rows],
        "Sessions": [row.metric_values[0].value for row in response.rows],
        "BidConversionRate": [row.metric_values[1].value for row in response.rows],
    })

    sessions = sessions.loc[(sessions["Browser"] != "") & (sessions["Browser"] != "(not set)")]
    sessions["Sessions"] = sessions["Sessions"].astype(int)
    sessions["BidConversionRate"] = sessions["BidConversionRate"].astype(float)

    sessions.fillna(0, inplace=True)

    return sessions

def getLostConnectionsSessions(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="browser"),
            Dimension(name="eventName")
        ],
        metrics=[
            Metric(name="eventCount"),
            Metric(name="sessions")
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])],
        dimension_filter=FilterExpression(
            filter=Filter(
                field_name="eventName",
                string_filter=Filter.StringFilter(value="lost_connection_modal"),
            )
        )
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("LostConnectionsSessions data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    lostConnections = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Browser": [row.dimension_values[1].value for row in response.rows],
        "LostConnectionsSessions": [row.metric_values[1].value for row in response.rows]
    })

    lostConnections = lostConnections.loc[(lostConnections["Browser"] != "") & (lostConnections["Browser"] != "(not set)")]
    lostConnections["LostConnectionsSessions"] = lostConnections["LostConnectionsSessions"].astype(int)
    lostConnections.fillna(0, inplace=True)

    return lostConnections

    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="customEvent:sale_id_event"),
            Dimension(name="customEvent:sale_country_event"),
            Dimension(name="customEvent:sale_type_event"),
            Dimension(name="customEvent:sale_car_number_event")
        ],
        metrics=[Metric(name="sessions")],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])]
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("SalesDimension data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    salesDimension = pd.DataFrame({
        "SaleId": [row.dimension_values[0].value for row in response.rows],
        "Country": [row.dimension_values[1].value for row in response.rows],
        "Type": [row.dimension_values[2].value for row in response.rows],
        "CarNumber": [row.dimension_values[3].value for row in response.rows]
    })

    salesDimension = salesDimension.loc[(salesDimension["Sale"] != "") & (salesDimension["Sale"] != "(not set)")]

    def aggregateDimension(series):
        series = series.drop_duplicates()
        list = series.to_list()
        if "null" in list: list.remove("null")
        if "(not set)" in list: list.remove("(not set)")
        if "" in list: list.remove("")
        return ' | '.join(list)

    salesDimension = salesDimension.groupby("Sale").agg({
        "Country": aggregateDimension,
        "Type": aggregateDimension,
        "CarNumber": aggregateDimension,
    }).reset_index()

    salesDimension["Country"] = salesDimension["Country"].astype(str)
    salesDimension["Type"] = salesDimension["Type"].astype(str)
    salesDimension["CarNumber"] = salesDimension["CarNumber"].astype(str)

    return salesDimension