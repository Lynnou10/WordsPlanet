from config.index import property_id, secret_key_path 
from google.oauth2 import service_account
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import (
    DateRange,
    Dimension,
    Metric,
    RunReportRequest,
    FilterExpression,
    Filter
)
import pandas as pd

def getInternalCampaignsMetrics(dateRanges, dataSourceName):
    credentials = service_account.Credentials.from_service_account_file(secret_key_path)
    client = BetaAnalyticsDataClient(credentials=credentials)

    data = None

    for dateRange in dateRanges:
        print("{source} importing from {startDate} to {endDate}".format(source=dataSourceName, startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
        campaignsData = getInternalCampaignsMetricsData(client, dateRange)
        campaignLoggedSessions = getInternalCampaignsLoggedSessions(client, dateRange)

        result = pd.merge(campaignsData, campaignLoggedSessions, on=["Date", "InternalCampaign"], how="outer")

        result["SessionsWithBids"] = result["Sessions"] * result["BidConversionRate"]
        result["SessionsWithBids"] = result["SessionsWithBids"].round()
        result["SessionsWithBids"] = result["SessionsWithBids"].astype(int)

        result["SessionsWithNewSignUps"] = result["Sessions"] * result["NewUserSignUpsConversionRate"]
        result["SessionsWithNewSignUps"] = result["SessionsWithNewSignUps"].round()
        result["SessionsWithNewSignUps"] = result["SessionsWithNewSignUps"].astype(int)

        result = result.drop(columns=['BidConversionRate', 'NewUserSignUpsConversionRate'])

        result = result.sort_values(by='Date', ascending=True)
        result.fillna(0, inplace=True)
        result["Sessions"] = result["Sessions"].astype(int)
        result["SessionsWithBids"] = result["SessionsWithBids"].astype(int)
        result["SessionsWithNewSignUps"] = result["SessionsWithNewSignUps"].astype(int)
        result["Bids"] = result["Bids"].astype(int)
        result["LoggedSessions"] = result["LoggedSessions"].astype(int)

        if data is not None:
            data = pd.concat([data, result], axis=0)
        else:
            data = result

    print("{source} imported".format(source=dataSourceName))
    return data

def getInternalCampaignsMetricsData(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="customEvent:ic_info_event"),
        ],
        metrics=[
            Metric(name="sessions"),
            Metric(name="conversions:bid_count"),
            Metric(name="sessionConversionRate:bid_count"),
            Metric(name="sessionConversionRate:new_user_signup_completed")
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])]
        
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("InternalCampaignsMetricsData data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    data = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "InternalCampaign": [row.dimension_values[1].value for row in response.rows],
        "Sessions": [row.metric_values[0].value for row in response.rows],
        "Bids": [row.metric_values[1].value for row in response.rows],
        "BidConversionRate": [row.metric_values[2].value for row in response.rows],
        "NewUserSignUpsConversionRate": [row.metric_values[2].value for row in response.rows],
    })

    data = data.loc[(data["InternalCampaign"] != "") & (data["InternalCampaign"] != "(not set)") & (data["InternalCampaign"] != "undefined | undefined | undefined | undefined")]
    data["Sessions"] = data["Sessions"].astype(int)
    data["Bids"] = data["Bids"].astype(int)
    data["BidConversionRate"] = data["BidConversionRate"].astype(float)
    data["NewUserSignUpsConversionRate"] = data["NewUserSignUpsConversionRate"].astype(float)


    data.fillna(0, inplace=True)

    return data

def getInternalCampaignsLoggedSessions(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="customEvent:ic_info_event")
        ],
        metrics=[Metric(name="sessions")],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])],
        dimension_filter=FilterExpression(
            filter=Filter(
                field_name="customUser:contains_user_info",
                string_filter=Filter.StringFilter(value="True"),
            )
        )
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("InternalCampaignsLoggedSessions data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    loggedSessions = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "InternalCampaign": [row.dimension_values[1].value for row in response.rows],
        "LoggedSessions": [row.metric_values[0].value for row in response.rows]
    })

    loggedSessions = loggedSessions.loc[(loggedSessions["InternalCampaign"] != "") & (loggedSessions["InternalCampaign"] != "(not set)") & (loggedSessions["InternalCampaign"] != "undefined | undefined | undefined | undefined")]
    loggedSessions["LoggedSessions"] = loggedSessions["LoggedSessions"].astype(int)
    loggedSessions.fillna(0, inplace=True)

    return loggedSessions
