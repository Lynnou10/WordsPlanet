from config.index import property_id, secret_key_path 
from google.oauth2 import service_account
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import (
    DateRange,
    Dimension,
    Metric,
    RunReportRequest
)
import pandas as pd

def getEventsCounts(dateRanges, dataSourceName):
    credentials = service_account.Credentials.from_service_account_file(secret_key_path)
    client = BetaAnalyticsDataClient(credentials=credentials)

    data = None

    for dateRange in dateRanges:
        print("{source} importing from {startDate} to {endDate}".format(source=dataSourceName, startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
        result = getEventsCountsData(client, dateRange)
        result = result.sort_values(by='Date', ascending=True)
        result.fillna(0, inplace=True)
        result["EventCount"] = result["EventCount"].astype(int)

        if data is not None:
            data = pd.concat([data, result], axis=0)
        else:
            data = result

    print("{source} imported".format(source=dataSourceName))
    return data

def getEventsCountsData(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="eventName")
        ],
        metrics=[
            Metric(name="eventCount")
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])]
        
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("EventsCounts data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    eventsCount = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "EventName": [row.dimension_values[1].value for row in response.rows],
        "EventCount": [row.metric_values[0].value for row in response.rows]
    })

    
    eventsCount["EventCount"] = eventsCount["EventCount"].astype(int)
    eventsCount.fillna(0, inplace=True)

    return eventsCount
