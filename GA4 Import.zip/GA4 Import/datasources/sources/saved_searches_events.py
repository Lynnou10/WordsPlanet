from config.index import property_id, secret_key_path 
from google.oauth2 import service_account
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import (
    DateRange,
    Dimension,
    Metric,
    RunReportRequest,
    FilterExpression,
    Filter
)
import pandas as pd

def getSavedSearchesEvents(dateRanges, dataSourceName):
    credentials = service_account.Credentials.from_service_account_file(secret_key_path)
    client = BetaAnalyticsDataClient(credentials=credentials)

    data = None

    for dateRange in dateRanges:
        print("{source} importing from {startDate} to {endDate}".format(source=dataSourceName, startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
        
        eventList = [
            {
                "eventName": "save_search_bell_click",
                "eventFullName": "SavedSearchBellClick"
            },
            {
                "eventName": "save_search_bell_click_visit",
                "eventFullName": "SavedSearchBellClickVisit"
            },
            {
                "eventName": "saved_search_display",
                "eventFullName": "SavedSearchDisplay"
            },
            {
                "eventName": "saved_search_display_visit",
                "eventFullName": "SavedSearchDisplayVisit"
            },
            {
                "eventName": "save_search_modal",
                "eventFullName": "SavedSearchModal"
            },
            {
                "eventName": "save_search_modal_visit",
                "eventFullName": "SavedSearchModalVisit"
            },
            {
                "eventName": "save_search_confirm_click",
                "eventFullName": "SavedSearchConfirmClick"
            },
            {
                "eventName": "save_search_confirm_click_visit",
                "eventFullName": "SavedSearchConfirmClickVisit"
            },
             {
                "eventName": "lots_page_visit",
                "eventFullName": "LotsPageVisit"
            }

        ]

        result = None

        for event in eventList:
            tmpResult = getEventCount(client, dateRange, event["eventName"], event["eventFullName"])

            if result is None:
                result = tmpResult
            else:
                result = pd.merge(result, tmpResult, on=["Date"], how="outer")
                # result.fillna(0, inplace=True)

            # result[event["eventFullName"]] = result[event["eventFullName"]].astype(int)

        result = result.sort_values(by='Date', ascending=True)
        result.fillna(0, inplace=True)
        

        if data is not None:
            data = pd.concat([data, result], axis=0)
        else:
            data = result

    print("{source} imported".format(source=dataSourceName))
    return data

def getEventCount(client, dateRange, eventName, eventFullName):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="eventName")
        ],
        metrics=[Metric(name="eventCount")],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])],
        dimension_filter=FilterExpression(
            filter=Filter(
                field_name="eventName",
                string_filter=Filter.StringFilter(value=eventName),
            )
        )
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("EventCount {eventName} data from {startDate} to {endDate} is sampled".format(eventName=eventFullName,startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    eventCount = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        eventFullName: [row.metric_values[0].value for row in response.rows]
    })


    eventCount[eventFullName] = eventCount[eventFullName].astype(int)

    eventCount.fillna(0, inplace=True)

    return eventCount
