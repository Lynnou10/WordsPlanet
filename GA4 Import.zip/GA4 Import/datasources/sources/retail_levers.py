from config.index import retail_property_id, secret_key_path 
from google.oauth2 import service_account
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import (
    DateRange,
    Dimension,
    Metric,
    RunReportRequest
)
import pandas as pd

def getRetailLevers(dateRanges, dataSourceName):
    credentials = service_account.Credentials.from_service_account_file(secret_key_path)
    client = BetaAnalyticsDataClient(credentials=credentials)

    data = None

    for dateRange in dateRanges:
        print("{source} importing from {startDate} to {endDate}".format(source=dataSourceName, startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
        result = getRetailCountryLevers(client, dateRange)

        result["SessionsWithCarContactInformation"] = result["Sessions"] * result["CarContactInformationConversionRate"]
        result["SessionsWithCarContactInformation"] = result["SessionsWithCarContactInformation"].round()
        result["SessionsWithCarContactInformation"] = result["SessionsWithCarContactInformation"].astype(int)

        result = result.drop(columns=['CarContactInformationConversionRate'])

        result = result.sort_values(by='Date', ascending=True)
        result.fillna(0, inplace=True)
        result["Sessions"] = result["Sessions"].astype(int)
        result["SessionsWithCarContactInformation"] = result["SessionsWithCarContactInformation"].astype(int)
        result["CarContactInformation"] = result["CarContactInformation"].astype(int)

        if data is not None:
            data = pd.concat([data, result], axis=0)
        else:
            data = result

    print("{source} imported".format(source=dataSourceName))
    return data

def getRetailCountryLevers(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{retail_property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="customEvent:site_country_event"),
            Dimension(name="sessionPrimaryChannelGroup")
        ],
        metrics=[
            Metric(name="sessions"),
            Metric(name="sessionConversionRate:car_contact_confirmation"),
            Metric(name="conversions:car_contact_confirmation")
            
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])]
        
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("RetailCountryLevers data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    data = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Country": [row.dimension_values[1].value for row in response.rows],
        "Lever": [row.dimension_values[2].value for row in response.rows],
        "Sessions": [row.metric_values[0].value for row in response.rows],
        "CarContactInformationConversionRate": [row.metric_values[1].value for row in response.rows],
        "CarContactInformation": [row.metric_values[2].value for row in response.rows]
    })

    data["Sessions"] = data["Sessions"].astype(int)
    data["CarContactInformationConversionRate"] = data["CarContactInformationConversionRate"].astype(float)
    data["CarContactInformation"] = data["CarContactInformation"].astype(int)
    data.fillna(0, inplace=True)

    return data

