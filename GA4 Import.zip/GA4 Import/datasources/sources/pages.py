from config.index import property_id, secret_key_path 
from google.oauth2 import service_account
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import (
    DateRange,
    Dimension,
    Metric,
    RunReportRequest,
    FilterExpression,
    Filter
)
import pandas as pd

def getPages(dateRanges, dataSourceName):
    credentials = service_account.Credentials.from_service_account_file(secret_key_path)
    client = BetaAnalyticsDataClient(credentials=credentials)

    data = None

    for dateRange in dateRanges:
        print("{source} importing from {startDate} to {endDate}".format(source=dataSourceName, startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
        pagesData = getPagesSessionBidsSignUps(client, dateRange)
        pagesLoggedSessions = getPagesLoggedSessions(client, dateRange)
        pagesSessionStart = getPagesSessionStart(client, dateRange)

        result = pd.merge(pagesData, pagesLoggedSessions, on=["Date", "Page", "Country"], how="outer")
        result = pd.merge(result, pagesSessionStart, on=["Date", "Page", "Country"], how="outer")

        result.fillna(0, inplace=True)
        result["SessionsWithBids"] = result["Sessions"] * result["BidConversionRate"]
        result["SessionsWithBids"] = result["SessionsWithBids"].round()
        result["SessionsWithBids"] = result["SessionsWithBids"].astype(int)

        result["SessionsWithSignUps"] = result["Sessions"] * result["SignUpConversionRate"]
        result["SessionsWithSignUps"] = result["SessionsWithSignUps"].round()
        result["SessionsWithSignUps"] = result["SessionsWithSignUps"].astype(int)

        result["SessionsWithExistingSignUps"] = result["Sessions"] * result["ExistingUserSignUpsConversionRate"]
        result["SessionsWithExistingSignUps"] = result["SessionsWithExistingSignUps"].round()
        result["SessionsWithExistingSignUps"] = result["SessionsWithExistingSignUps"].astype(int)

        result["TotalSessionsDuration"] = result["Sessions"] * result["AverageSessionDuration"]
        result["TotalSessionsDuration"] = result["TotalSessionsDuration"].round()
        result["TotalSessionsDuration"] = result["TotalSessionsDuration"].astype(int)

        result["TotalBounce"] = result["Sessions"] * result["BounceRate"]
        result["TotalBounce"] = result["TotalBounce"].round()
        result["TotalBounce"] = result["TotalBounce"].astype(int)

        result = result.drop(columns=['BidConversionRate', 'SignUpConversionRate', 'ExistingUserSignUpsConversionRate', 'AverageSessionDuration', 'BounceRate'])

        result = result.sort_values(by='Date', ascending=True)
        result.fillna(0, inplace=True)
        result["Sessions"] = result["Sessions"].astype(int)
        result["SessionsWithBids"] = result["SessionsWithBids"].astype(int)
        result["SessionsWithSignUps"] = result["SessionsWithSignUps"].astype(int)
        result["SessionsWithExistingSignUps"] = result["SessionsWithExistingSignUps"].astype(int)
        result["TotalSessionsDuration"] = result["TotalSessionsDuration"].astype(int)
        result["TotalBounce"] = result["TotalBounce"].astype(int)
        result["LoggedSessions"] = result["LoggedSessions"].astype(int)
        result["SessionStart"] = result["SessionStart"].astype(int)
        result["Bids"] = result["Bids"].astype(int)
        result["UserEngagementDuration"] = result["UserEngagementDuration"].astype(float)

        if data is not None:
            data = pd.concat([data, result], axis=0)
        else:
            data = result

    print("{source} imported".format(source=dataSourceName))
    return data

def getPagesSessionBidsSignUps(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="customEvent:page_name_event"),
            Dimension(name="customEvent:site_country_event")
        ],
        metrics=[
            Metric(name="sessions"),
            Metric(name="sessionConversionRate:new_user_signup_completed"),
            Metric(name="sessionConversionRate:bid_count"),
            Metric(name="sessionConversionRate:existing_user_signup"),
            Metric(name="averageSessionDuration"),
            Metric(name="bounceRate"),
            Metric(name="screenPageViews"),
            Metric(name="conversions:bid_count"),
            Metric(name="userEngagementDuration")
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])]
        
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("PagesSessionBidsSignUps data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    sessionsWithBidsSignUps = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Page": [row.dimension_values[1].value for row in response.rows],
        "Country": [row.dimension_values[2].value for row in response.rows],
        "Sessions": [row.metric_values[0].value for row in response.rows],
        "SignUpConversionRate": [row.metric_values[1].value for row in response.rows],
        "BidConversionRate": [row.metric_values[2].value for row in response.rows],
        "ExistingUserSignUpsConversionRate": [row.metric_values[3].value for row in response.rows],
        "AverageSessionDuration": [row.metric_values[4].value for row in response.rows],
        "BounceRate": [row.metric_values[5].value for row in response.rows],
        "PageViews": [row.metric_values[6].value for row in response.rows],
        "Bids": [row.metric_values[7].value for row in response.rows],
        "UserEngagementDuration": [row.metric_values[8].value for row in response.rows]
    })

    sessionsWithBidsSignUps = sessionsWithBidsSignUps.loc[(sessionsWithBidsSignUps["Page"] != "") & (sessionsWithBidsSignUps["Page"] != "(not set)")]
    sessionsWithBidsSignUps["Sessions"] = sessionsWithBidsSignUps["Sessions"].astype(int)
    sessionsWithBidsSignUps["SignUpConversionRate"] = sessionsWithBidsSignUps["SignUpConversionRate"].astype(float)
    sessionsWithBidsSignUps["BidConversionRate"] = sessionsWithBidsSignUps["BidConversionRate"].astype(float)
    sessionsWithBidsSignUps["ExistingUserSignUpsConversionRate"] = sessionsWithBidsSignUps["ExistingUserSignUpsConversionRate"].astype(float)
    sessionsWithBidsSignUps["AverageSessionDuration"] = sessionsWithBidsSignUps["AverageSessionDuration"].astype(float)
    sessionsWithBidsSignUps["BounceRate"] = sessionsWithBidsSignUps["BounceRate"].astype(float)
    sessionsWithBidsSignUps["PageViews"] = sessionsWithBidsSignUps["PageViews"].astype(int)
    sessionsWithBidsSignUps["UserEngagementDuration"] = sessionsWithBidsSignUps["UserEngagementDuration"].astype(float)
    sessionsWithBidsSignUps.fillna(0, inplace=True)

    return sessionsWithBidsSignUps

def getPagesLoggedSessions(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="customEvent:page_name_event"),
            Dimension(name="customEvent:site_country_event")
        ],
        metrics=[Metric(name="sessions")],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])],
        dimension_filter=FilterExpression(
            filter=Filter(
                field_name="customUser:contains_user_info",
                string_filter=Filter.StringFilter(value="True"),
            )
        )
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("PagesLoggedSessions data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    loggedSessions = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Page": [row.dimension_values[1].value for row in response.rows],
        "Country": [row.dimension_values[2].value for row in response.rows],
        "LoggedSessions": [row.metric_values[0].value for row in response.rows]
    })

    loggedSessions["LoggedSessions"] = loggedSessions["LoggedSessions"].astype(int)
    loggedSessions.fillna(0, inplace=True)

    return loggedSessions


def getPagesSessionStart(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="customEvent:page_name_event"),
            Dimension(name="customEvent:site_country_event"),
        ],
        metrics=[Metric(name="eventCount")],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])],
        dimension_filter=FilterExpression(
            filter=Filter(
                field_name="eventName",
                string_filter=Filter.StringFilter(value="session_start"),
            )
        )
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("getPagesSessionStart data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    sessionStarts = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Page": [row.dimension_values[1].value for row in response.rows],
        "Country": [row.dimension_values[2].value for row in response.rows],
        "SessionStart": [row.metric_values[0].value for row in response.rows]
    })

    sessionStarts["SessionStart"] = sessionStarts["SessionStart"].astype(int)
    sessionStarts.fillna(0, inplace=True)

    return sessionStarts
