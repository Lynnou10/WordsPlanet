from config.index import property_id, secret_key_path 
from google.oauth2 import service_account
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import (
    DateRange,
    Dimension,
    Metric,
    RunReportRequest
)
import pandas as pd

def getInternalSearchQueries(dateRanges, dataSourceName):
    credentials = service_account.Credentials.from_service_account_file(secret_key_path)
    client = BetaAnalyticsDataClient(credentials=credentials)

    data = None

    for dateRange in dateRanges:
        print("{source} importing from {startDate} to {endDate}".format(source=dataSourceName, startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
        result = getInternalSearchQueriesSessionBids(client, dateRange)

        result["SessionsWithBids"] = result["Sessions"] * result["BidConversionRate"]
        result["SessionsWithBids"] = result["SessionsWithBids"].round()
        result["SessionsWithBids"] = result["SessionsWithBids"].astype(int)

        result = result.drop(columns=['BidConversionRate'])

        result = result.sort_values(by='Date', ascending=True)
        result.fillna(0, inplace=True)
        result["Sessions"] = result["Sessions"].astype(int)
        result["SessionsWithBids"] = result["SessionsWithBids"].astype(int)
        result["Bids"] = result["Bids"].astype(int)

        if data is not None:
            data = pd.concat([data, result], axis=0)
        else:
            data = result

    print("{source} imported".format(source=dataSourceName))
    return data

def getInternalSearchQueriesSessionBids(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="customEvent:search_queries_event")
        ],
        metrics=[
            Metric(name="sessions"),
            Metric(name="sessionConversionRate:bid_count"),
            Metric(name="conversions:bid_count")
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])]
        
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("InternalSearchQueriesSessionBids data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    sessionsWithBids = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "SearchQuery": [row.dimension_values[1].value for row in response.rows],
        "Sessions": [row.metric_values[0].value for row in response.rows],
        "BidConversionRate": [row.metric_values[1].value for row in response.rows],
        "Bids": [row.metric_values[2].value for row in response.rows]
    })

    sessionsWithBids = sessionsWithBids.loc[(sessionsWithBids["SearchQuery"] != "") & (sessionsWithBids["SearchQuery"] != "(not set)")]
    sessionsWithBids["Sessions"] = sessionsWithBids["Sessions"].astype(int)
    sessionsWithBids["BidConversionRate"] = sessionsWithBids["BidConversionRate"].astype(float)
    sessionsWithBids["Bids"] = sessionsWithBids["Bids"].astype(int)
    sessionsWithBids.fillna(0, inplace=True)

    return sessionsWithBids
