from config.index import property_id, secret_key_path 
from google.oauth2 import service_account
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import (
    DateRange,
    Dimension,
    Metric,
    RunReportRequest,
    FilterExpression,
    Filter
)
import pandas as pd

def getSales(dateRanges, dataSourceName):
    credentials = service_account.Credentials.from_service_account_file(secret_key_path)
    client = BetaAnalyticsDataClient(credentials=credentials)

    data = None

    for dateRange in dateRanges:
        print("{source} importing from {startDate} to {endDate}".format(source=dataSourceName, startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
        sessionsWithBids = getSalesSessionWithBids(client, dateRange)
        salesLoggedSessions = getSalesLoggedSessions(client, dateRange)
        salesHits = getSalesHits(client, dateRange)

        result = pd.merge(sessionsWithBids, salesLoggedSessions, on=["Date", "Sale"], how="outer")
        result = pd.merge(result, salesHits, on=["Date", "Sale"], how="outer")

        result["SessionsWithBids"] = result["Sessions"] * result["BidConversionRate"]
        result["SessionsWithBids"] = result["SessionsWithBids"].round()
        # result["SessionsWithBids"] = result["SessionsWithBids"].astype(int)

        result = result.drop(columns=['BidConversionRate'])
        result = result[["Date", "Sale", "Sessions", "LoggedSessions", "SessionsWithBids", "Bids", "Hits"]]

        result = result.sort_values(by='Date', ascending=True)
        result.fillna(0, inplace=True)
        result["Sessions"] = result["Sessions"].astype(int)
        result["LoggedSessions"] = result["LoggedSessions"].astype(int)
        result["SessionsWithBids"] = result["SessionsWithBids"].astype(int)
        result["Bids"] = result["Bids"].astype(int)
        result["Hits"] = result["Hits"].astype(int)

        if data is not None:
            data = pd.concat([data, result], axis=0)
        else:
            data = result

    print("{source} imported".format(source=dataSourceName))
    return data

def getSalesLoggedSessions(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="customEvent:sale_info_event")
        ],
        metrics=[Metric(name="sessions")],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])],
        dimension_filter=FilterExpression(
            filter=Filter(
                field_name="customUser:contains_user_info",
                string_filter=Filter.StringFilter(value="True"),
            )
        )
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("SalesLoggedSession data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    loggedSessions = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Sale": [row.dimension_values[1].value for row in response.rows],
        "LoggedSessions": [row.metric_values[0].value for row in response.rows]
    })

    loggedSessions = loggedSessions.loc[(loggedSessions["Sale"] != "") & (loggedSessions["Sale"] != "(not set)")]
    loggedSessions["LoggedSessions"] = loggedSessions["LoggedSessions"].astype(int)
    loggedSessions.fillna(0, inplace=True)

    return loggedSessions

def getSalesSessionWithBids(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="customEvent:sale_info_event")
        ],
        metrics=[
            Metric(name="sessions"),
            Metric(name="sessionConversionRate:bid_count"),
            Metric(name="conversions:bid_count")
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])]
        
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("SalesSessionWithBids data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    sessionsWithBids = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Sale": [row.dimension_values[1].value for row in response.rows],
        "Sessions": [row.metric_values[0].value for row in response.rows],
        "BidConversionRate": [row.metric_values[1].value for row in response.rows],
        "Bids": [row.metric_values[2].value for row in response.rows],
    })

    sessionsWithBids = sessionsWithBids.loc[(sessionsWithBids["Sale"] != "") & (sessionsWithBids["Sale"] != "(not set)")]
    sessionsWithBids["BidConversionRate"] = sessionsWithBids["BidConversionRate"].astype(float)
    sessionsWithBids["Sessions"] = sessionsWithBids["Sessions"].astype(int)
    sessionsWithBids["Bids"] = sessionsWithBids["Bids"].astype(int)

    sessionsWithBids.fillna(0, inplace=True)

    return sessionsWithBids

def getSalesHits(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="customEvent:sale_info_event"),
            Dimension(name="eventName")
        ],
        metrics=[Metric(name="eventCount")],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])],
        dimension_filter=FilterExpression(
            filter=Filter(
                field_name="eventName",
                string_filter=Filter.StringFilter(value="sale_page_view"),
            )
        )
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("SalesHits data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    salesHits = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "Sale": [row.dimension_values[1].value for row in response.rows],
        "Hits": [row.metric_values[0].value for row in response.rows]
    })

    salesHits = salesHits.loc[(salesHits["Sale"] != "") & (salesHits["Sale"] != "(not set)")]

    salesHits["Hits"] = salesHits["Hits"].astype(int)

    salesHits.fillna(0, inplace=True)

    return salesHits

def getSalesDimension(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="customEvent:sale_id_event"),
            Dimension(name="customEvent:sale_country_event"),
            Dimension(name="customEvent:sale_type_event"),
            Dimension(name="customEvent:sale_car_number_event")
        ],
        metrics=[Metric(name="sessions")],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])]
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("SalesDimension data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    salesDimension = pd.DataFrame({
        "SaleId": [row.dimension_values[0].value for row in response.rows],
        "Country": [row.dimension_values[1].value for row in response.rows],
        "Type": [row.dimension_values[2].value for row in response.rows],
        "CarNumber": [row.dimension_values[3].value for row in response.rows]
    })

    salesDimension = salesDimension.loc[(salesDimension["Sale"] != "") & (salesDimension["Sale"] != "(not set)")]

    def aggregateDimension(series):
        series = series.drop_duplicates()
        list = series.to_list()
        if "null" in list: list.remove("null")
        if "(not set)" in list: list.remove("(not set)")
        if "" in list: list.remove("")
        return ' | '.join(list)

    salesDimension = salesDimension.groupby("Sale").agg({
        "Country": aggregateDimension,
        "Type": aggregateDimension,
        "CarNumber": aggregateDimension,
    }).reset_index()

    salesDimension["Country"] = salesDimension["Country"].astype(str)
    salesDimension["Type"] = salesDimension["Type"].astype(str)
    salesDimension["CarNumber"] = salesDimension["CarNumber"].astype(str)

    return salesDimension