from config.index import property_id, secret_key_path 
from google.oauth2 import service_account
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import (
    DateRange,
    Dimension,
    Metric,
    RunReportRequest,
    FilterExpression,
    Filter
)
import pandas as pd

def getSalesTypes(dateRanges, dataSourceName):
    credentials = service_account.Credentials.from_service_account_file(secret_key_path)
    client = BetaAnalyticsDataClient(credentials=credentials)

    data = None

    for dateRange in dateRanges:
        print("{source} importing from {startDate} to {endDate}".format(source=dataSourceName, startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
        sessionsWithBids = getSalesTypesSessionWithBids(client, dateRange)
        salesLoggedSessions = getSalesTypesLoggedSessions(client, dateRange)
        salesHits = getSalesTypesHits(client, dateRange)

        result = pd.merge(sessionsWithBids, salesLoggedSessions, on=["Date", "SaleId", "SaleCountry", "SaleType"], how="outer")
        result = pd.merge(result, salesHits, on=["Date", "SaleId", "SaleCountry", "SaleType"], how="outer")

        result["SessionsWithBids"] = result["Sessions"] * result["BidConversionRate"]
        result["SessionsWithBids"] = result["SessionsWithBids"].round()
        # result["SessionsWithBids"] = result["SessionsWithBids"].astype(int)

        result = result.drop(columns=['BidConversionRate'])
        result = result[["Date", "SaleId", "SaleCountry", "SaleType", "Sessions", "LoggedSessions", "SessionsWithBids", "Bids", "Hits"]]

        result.loc[result['SaleId'] is None or result['SaleId'] == '', 'SaleId'] = '(not set)'
        result.loc[result['SaleCountry'] is None or result['SaleCountry'] == '', 'SaleCountry'] = '(not set)'
        result.loc[result['SaleType'] is None or result['SaleType'] == '', 'SaleType'] = '(not set)'

        result = result.sort_values(by='Date', ascending=True)
        result.fillna(0, inplace=True)
        result["Sessions"] = result["Sessions"].astype(int)
        result["LoggedSessions"] = result["LoggedSessions"].astype(int)
        result["SessionsWithBids"] = result["SessionsWithBids"].astype(int)
        result["Bids"] = result["Bids"].astype(int)
        result["Hits"] = result["Hits"].astype(int)

        if data is not None:
            data = pd.concat([data, result], axis=0)
        else:
            data = result

    print("{source} imported".format(source=dataSourceName))
    return data

def getSalesTypesLoggedSessions(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="customEvent:sale_id_event"),
            Dimension(name="customEvent:sale_country_event"),
            Dimension(name="customEvent:sale_type_event")
        ],
        metrics=[Metric(name="sessions")],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])],
        dimension_filter=FilterExpression(
            filter=Filter(
                field_name="customUser:contains_user_info",
                string_filter=Filter.StringFilter(value="True"),
            )
        )
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("SalesTypesLoggedSession data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    loggedSessions = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "SaleId": [row.dimension_values[1].value for row in response.rows],
        "SaleCountry": [row.dimension_values[2].value for row in response.rows],
        "SaleType": [row.dimension_values[3].value for row in response.rows],
        "LoggedSessions": [row.metric_values[0].value for row in response.rows]
    })

    # loggedSessions = loggedSessions.loc[(loggedSessions["SaleId"] == "") | (loggedSessions["SaleId"] == "(not set)") | (loggedSessions["SaleCountry"] == "") | (loggedSessions["SaleCountry"] == "(not set)") | (loggedSessions["SaleType"] == "") | (loggedSessions["SaleType"] == "(not set)")]
    loggedSessions["LoggedSessions"] = loggedSessions["LoggedSessions"].astype(int)
    loggedSessions.fillna(0, inplace=True)

    return loggedSessions

def getSalesTypesSessionWithBids(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="customEvent:sale_id_event"),
            Dimension(name="customEvent:sale_country_event"),
            Dimension(name="customEvent:sale_type_event")
        ],
        metrics=[
            Metric(name="sessions"),
            Metric(name="sessionConversionRate:bid_count"),
            Metric(name="conversions:bid_count")
        ],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])]
        
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("SalesTypesSessionWithBids data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    sessionsWithBids = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "SaleId": [row.dimension_values[1].value for row in response.rows],
        "SaleCountry": [row.dimension_values[2].value for row in response.rows],
        "SaleType": [row.dimension_values[3].value for row in response.rows],
        "Sessions": [row.metric_values[0].value for row in response.rows],
        "BidConversionRate": [row.metric_values[1].value for row in response.rows],
        "Bids": [row.metric_values[2].value for row in response.rows],
    })

    # sessionsWithBids = sessionsWithBids.loc[(sessionsWithBids["SaleId"] == "") | (sessionsWithBids["SaleId"] == "(not set)") | (sessionsWithBids["SaleCountry"] == "") | (sessionsWithBids["SaleCountry"] == "(not set)") | (sessionsWithBids["SaleType"] == "") | (sessionsWithBids["SaleType"] == "(not set)")]
    sessionsWithBids["BidConversionRate"] = sessionsWithBids["BidConversionRate"].astype(float)
    sessionsWithBids["Sessions"] = sessionsWithBids["Sessions"].astype(int)
    sessionsWithBids["Bids"] = sessionsWithBids["Bids"].astype(int)

    sessionsWithBids.fillna(0, inplace=True)

    return sessionsWithBids

def getSalesTypesHits(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date"),
            Dimension(name="customEvent:sale_id_event"),
            Dimension(name="customEvent:sale_country_event"),
            Dimension(name="customEvent:sale_type_event"),
            Dimension(name="eventName")
        ],
        metrics=[Metric(name="eventCount")],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])],
        dimension_filter=FilterExpression(
            filter=Filter(
                field_name="eventName",
                string_filter=Filter.StringFilter(value="sale_page_view"),
            )
        )
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("SalesTypesHits data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    salesHits = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "SaleId": [row.dimension_values[1].value for row in response.rows],
        "SaleCountry": [row.dimension_values[2].value for row in response.rows],
        "SaleType": [row.dimension_values[3].value for row in response.rows],
        "Hits": [row.metric_values[0].value for row in response.rows]
    })

    # salesHits = salesHits.loc[(salesHits["SaleId"] == "") | (salesHits["SaleId"] == "(not set)") | (salesHits["SaleCountry"] == "") | (salesHits["SaleCountry"] == "(not set)") | (salesHits["SaleType"] == "") | (salesHits["SaleType"] == "(not set)")]
    salesHits["Hits"] = salesHits["Hits"].astype(int)

    salesHits.fillna(0, inplace=True)

    return salesHits
