from config.index import property_id, secret_key_path 
from google.oauth2 import service_account
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import (
    DateRange,
    Dimension,
    Metric,
    RunReportRequest,
    FilterExpression,
    Filter
)
import pandas as pd

def getVisitors(dateRanges, dataSourceName):
    credentials = service_account.Credentials.from_service_account_file(secret_key_path)
    client = BetaAnalyticsDataClient(credentials=credentials)

    data = None

    for dateRange in dateRanges:
        print("{source} importing from {startDate} to {endDate}".format(source=dataSourceName, startDate=dateRange["startDate"], endDate=dateRange["endDate"]))

        result = getVisitorsData(client, dateRange)
        result["TotalUsers"] = result["TotalUsers"].astype(int)
        result = result.sort_values(by='Date', ascending=True)
        result.fillna(0, inplace=True)
        result["TotalUsers"] = result["TotalUsers"].astype(int)

        if data is not None:
            data = pd.concat([data, result], axis=0)
        else:
            data = result

    print("{source} imported".format(source=dataSourceName))
    return data

def getVisitorsData(client, dateRange):
    request = RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="date")
        ],
        metrics=[Metric(name="totalUsers")],
        date_ranges=[DateRange(start_date=dateRange["startDate"], end_date=dateRange["endDate"])]
    )
    response = client.run_report(request)
    
    if(response.metadata.subject_to_thresholding):
        raise ValueError("Visitors data from {startDate} to {endDate} is sampled".format(startDate=dateRange["startDate"], endDate=dateRange["endDate"]))
    
    visitors = pd.DataFrame({
        "Date": [row.dimension_values[0].value for row in response.rows],
        "TotalUsers": [row.metric_values[0].value for row in response.rows]
    })

    visitors["TotalUsers"] = visitors["TotalUsers"].astype(int)
    visitors.fillna(0, inplace=True)

    return visitors
