from datasources.sources.sales import getSales
from datasources.sources.sales_types import getSalesTypes
from datasources.sources.filters import getFilters
from datasources.sources.levers import getLevers
from datasources.sources.internal_search_query import getInternalSearchQueries
from datasources.sources.filter_countries import getFilterCountries
from datasources.sources.filter_models import getFilterModels
from datasources.sources.filter_makes import getFilterMakes
from datasources.sources.filter_saletypes import getFilterSaleTypes
from datasources.sources.filter_fueltypes import getFilterFuelTypes
from datasources.sources.events_count import getEventsCounts
from datasources.sources.visitors import getVisitors
from datasources.sources.logged_sessions import getLoggedSessions
from datasources.sources.sessions_with_bids import getSessionsWithBids
from datasources.sources.sessions import getSessions
from datasources.sources.campaigns import getCampaigns
from datasources.sources.campaigns_details import getCampaignsDetails
from datasources.sources.campaigns_metrics import getCampaignsMetrics
from datasources.sources.countries import getCountries
from datasources.sources.devices import getDevices
from datasources.sources.internal_campaigns_metrics import getInternalCampaignsMetrics
from datasources.sources.saved_searches import getSavedSearches
from datasources.sources.saved_searches_events import getSavedSearchesEvents
from datasources.sources.devices_countries import getDevicesCountries
from datasources.sources.lost_connections import getLostConnections
from datasources.sources.abtasty import getABTasty
from datasources.sources.emails_metrics import getEmailsMetrics
from datasources.sources.campaigns_clicks import getCampaignsClicks
from datasources.sources.roi import getROI
from datasources.sources.pages import getPages
from datasources.sources.elec_fitler import getElecFilter
from datasources.sources.country_search import getCountrySearch
from datasources.sources.country_fueltypes import getCountryFuelTypes
from datasources.sources.country_makes import getCountryMakes
from datasources.sources.country_models import getCountryModels
from datasources.sources.country_saletypes import getCountrySaleTypes
from datasources.sources.lever_signups import getLeverSignUps
from datasources.sources.retail_levers import getRetailLevers
from datasources.sources.retail_campaigns import getRetailCampaigns
from datasources.sources.mediums import getMediums
from datasources.sources.sources import getSources
from datasources.sources.sources_mediums import getSourcesMediums
from datasources.sources.campaigns_mediums_metrics import getCampaignsMediumsMetrics
from datasources.sources.server_time import getServerTimesMetrics
from datasources.sources.levers_country import getLeversCountry

datasources = {
    "GA4 - Sales": getSales,
    # "GA4 - Filters": getFilters,
    "GA4 - Levers": getLevers,
    "GA4 - Internal Search Query": getInternalSearchQueries,
    # "GA4 - Filter Countries": getFilterCountries,
    "GA4 - Events Count": getEventsCounts,
    "GA4 - Visitors": getVisitors,
    "GA4 - Logged Sessions": getLoggedSessions,
    "GA4 - Sessions with Bids": getSessionsWithBids,
    "GA4 - Sessions": getSessions,
    # "GA4 - Campaigns": getCampaigns,
    # "GA4 - Campaigns Details": getCampaignsDetails,
    # "GA4 - Campaigns Metrics": getCampaignsMetrics,
    # "GA4 - Filter Sale Types": getFilterSaleTypes,
    # "GA4 - Filter Models": getFilterModels,
    # "GA4 - Filter Makes": getFilterMakes,
    # "GA4 - Filter Fuel Types": getFilterFuelTypes,
    # "GA4 - Countries": getCountries,
    "GA4 - Devices": getDevices,
    "GA4 - Internal Campaigns Metrics": getInternalCampaignsMetrics,
    "GA4 - Sales Types": getSalesTypes,
    "GA4 - Saved Searches": getSavedSearches,
    "GA4 - Saved Searches Events": getSavedSearchesEvents,
    "GA4 - Devices Countries": getDevicesCountries,
    "GA4 - Lost Connections": getLostConnections,
    "GA4 - ABTasty": getABTasty,
    "GA4 - Emails Metrics": getEmailsMetrics,
    # "GA4 - Campaigns Clicks": getCampaignsClicks,
    "GA4 - ROI": getROI,
    "GA4 - Pages": getPages,
    "GA4 - Elec Filter": getElecFilter,
    # "GA4 - Country Search": getCountrySearch,
    # "GA4 - Country FuelTypes": getCountryFuelTypes,
    # "GA4 - Country Makes": getCountryMakes,
    # "GA4 - Country Models": getCountryModels,
    # "GA4 - Country SaleTypes": getCountrySaleTypes,
    "GA4 - Lever SignUps": getLeverSignUps,
    "GA4 - Retail Levers": getRetailLevers,
    "GA4 - Retail Campaigns": getRetailCampaigns,
    "GA4 - Mediums": getMediums,
    "GA4 - Sources": getSources,
    "GA4 - Sources Mediums": getSourcesMediums,
    # "GA4 - Campaigns Mediums Metrics": getCampaignsMediumsMetrics,
    "GA4 - Server Time": getServerTimesMetrics,
    "GA4 - Levers Country": getLeversCountry
}