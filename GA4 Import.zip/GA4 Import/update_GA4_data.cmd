python ./update_GA4_data.py
pause